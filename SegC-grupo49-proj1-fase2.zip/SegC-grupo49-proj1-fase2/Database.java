import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.security.spec.KeySpec;
import java.io.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Database class represents a database for managing sensor devices, users, domains, and associated data.
 */
public class Database {

    Queue<SensorDevice> loggedInDevices;
    Queue<String> activeUsers;
    Queue<String> activeDevices;
    Queue<String> temps; //os Sensores que estão nesta queue têm temperaturas
    String hmacKey;
    byte[] currHMAC;
    byte[] currIV = null;
    byte[] algParam;
    byte[] salt = {(byte) 0x54, (byte) 0x54, (byte) 0x54, (byte) 0x54, (byte) 0x54, (byte) 0x54, (byte) 0x54, (byte) 0x54};

    ConcurrentHashMap<String, Domain> domains; //Domain name
    ConcurrentHashMap<String, File> images;

    public final String USERS_FILE = "./FicheirosServidor/users.txt";
    public final String DOMAINS_FILE = "./FicheirosServidor/domains.txt";
    public final String TEMP_FILE = "./FicheirosServidor/temp.txt";
    public final String VARIABLES = "./FicheirosServidor/variables.txt";

    /**
     * Constructs a Database object.
     * Initializes queues and ConcurrentHashMaps.
     * Creates necessary files if they don't exist.
     * @throws NoSuchPaddingException 
     * @throws NoSuchAlgorithmException 
     * @throws InvalidKeyException 
     */
    public Database(String hmacKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException{

        this.hmacKey = hmacKey;

        this.loggedInDevices = new ConcurrentLinkedQueue<SensorDevice>();
        this.activeUsers = new ConcurrentLinkedQueue<String>();
        this.activeDevices = new ConcurrentLinkedQueue<String>();
        this.temps = new ConcurrentLinkedQueue<String>();

        this.domains = new ConcurrentHashMap<String, Domain>();
        this.images = new ConcurrentHashMap<String, File>();

        File directoryServer = new File("FicheirosServidor");
        if (!directoryServer.exists()) {
            directoryServer.mkdirs(); 
        }
        try{

            File devFile = new File("./FicheirosServidor/dev_file.txt");
            if(!devFile.exists()){
                devFile.createNewFile();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("IoTDevice.jar").append(System.lineSeparator()).append("1348493");  //dev_file.txt
                BufferedWriter writer = new BufferedWriter(new FileWriter(devFile.getAbsoluteFile()));
                writer.write(stringBuilder.toString());
                writer.close();
            }
            
        } catch (Exception e){
            System.out.println("Erro ao criar os ficheiros do sistema!");
            e.printStackTrace();
        }
    }

    /**
     * Restores the database from stored files.
     * Reads domain information, temperatures, images, and active users from files.
     * @throws Exception 
     */
    public void restoreDatabaseFromFiles(String password) throws Exception{
        File varfile = new File(VARIABLES);
        if (!varfile.exists()) {
            varfile.createNewFile();
            
            SecureRandom random = new SecureRandom();
            byte[] randomBytes = new byte[32];
            random.nextBytes(randomBytes);

            SecretKeySpec secretKey = new SecretKeySpec(hmacKey.getBytes(), "HmacSHA256");
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(secretKey);
            currHMAC = mac.doFinal(randomBytes);
        } else {
            BufferedReader reader = new BufferedReader(new FileReader(VARIABLES));
            String line = reader.readLine(); // Read the first line
            if(line != null){
                String[] byteStrings = line.split("\\s+"); // Split by whitespace
        
                byte[] byteArray = new byte[byteStrings.length];
                for (int i = 0; i < byteStrings.length; i++) {
                    byteArray[i] = Byte.parseByte(byteStrings[i]); // Parse each substring as a byte
                }

                algParam = byteArray;
                
                if ((line = reader.readLine()) != null) {
                    byteStrings = line.split(" "); // Split the line by spaces
                    byteArray = new byte[byteStrings.length];
                    for (int i = 0; i < byteStrings.length; i++) {
                        byteArray[i] = Byte.parseByte(byteStrings[i]); // Parse each byte string to a byte value
                    }
                    currHMAC = byteArray;
                }
            }
            reader.close();
        }

        //atualizar dominios
        try {

            File domainFile = new File(DOMAINS_FILE);
            if (!domainFile.exists()) {
                domainFile.createNewFile();
            } else {
                BufferedReader reader = new BufferedReader(new FileReader(DOMAINS_FILE));
                String line = reader.readLine();
                boolean lookingDomain = true;
                Domain lastDomain = null;
                while (line != null) {  
                    if(lookingDomain){
                        String[] domain = line.split(":");
                        String[] users = domain[1].split(",");
                        Domain dm = new Domain(domain[0], users[0]);
                        for (int i = 1; i < users.length; i++) {
                            if(!activeUsers.contains(users[i])) {
                                activeUsers.add(users[i]);
                            }
                            dm.addUser(users[i]);
                        }
                        domains.put(domain[0], dm);
                        lastDomain = dm;
                    
                    } else {
                        String[] sensors = line.split(",");
                        for (String sensor : sensors) {
                            if(sensor.contains(":")) {
                                String userId = sensor.split(":")[0];
                                int devId = Integer.parseInt(sensor.split(":")[1]);
                                SensorDevice sd = new SensorDevice(userId, devId);
                                if(!activeDevices.contains(sd.toString())) {
                                    activeDevices.add(sd.toString());
                                }
                                lastDomain.addDevice(sd);
                            }
                        }
                    }
                    line = reader.readLine();
                    lookingDomain = !lookingDomain;
                }
                reader.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        File tempsfile = new File(TEMP_FILE);
        if (!tempsfile.exists() || currHMAC == null) {
            tempsfile.createNewFile();
        }
        else {
            // Procurar as temperatura dos Domains e adicionar a temps
            try {
                String content;
                // Verify the HMAC before processing the file content
                if ((content = verifyHMACTemperature(TEMP_FILE)) == null) {
                    System.out.println("HMAC verification failed for TEMP_FILE.");
                    return;
                }

                // Process the hashed content to extract relevant information
                BufferedReader reader = new BufferedReader(new StringReader(content));
                String line;
                while ((line = reader.readLine()) != null) {                
                    String[] info = line.split(",");
                    if (info.length == 2) {
                        temps.add(info[0]);
                    }
                }

                reader.close();
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }

        // Procurar as imagens dos SensorDevice e adicionar a images
        try {
            File f = new File("./FicheirosServidor");

            FilenameFilter filter = new FilenameFilter() {
                @Override
                public boolean accept(File f, String name) {
                    return name.endsWith(".jpg");
                }
            };

            File[] files = f.listFiles(filter);

            for (int i = 0; i < files.length; i++) {
                String[] ids = files[i].getName().split(",");
                images.put(ids[0] + ":" + ids[1], files[i]);
            }
        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        File usersfile = new File(USERS_FILE);
        if (usersfile.exists()){
            // Adicionar os users
            try {
                Scanner reader = new Scanner(decryptFile(USERS_FILE, password));
                String line = reader.nextLine();
                String user = "";
                while (reader.hasNext()) {
                    user = line.split(":")[0];
                    if(!activeUsers.contains(user)) {
                        activeUsers.add(user);
                    }
                    line = reader.nextLine();
                }
                reader.close();
            } catch (Exception e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
    }

    /**
     * Handles client connection requests.
     * Authenticates users and grants access accordingly.
     * @param fromClientCredencials Credentials sent by the client for authentication.
     * @return Response indicating the status of the authentication process.
     * @throws IOException If an I/O error occurs.
     * @throws InvalidKeySpecException 
     * @throws NoSuchAlgorithmException 
     */
    public RespostaSrv handleClientConnection(String fromClientCredentials, String password) throws Exception {
        try {
            File file = new File(USERS_FILE);
            if (file.exists()){ //currIV != null
                String decryptedContent = decryptFile(USERS_FILE, password);

                // Split decryptedContent into lines and iterate over them to find a match
                String[] lines = decryptedContent.split("\n");
                
                for (String line : lines) {
                    if (line.split(":")[0].equals(fromClientCredentials)) {
                        return RespostaSrv.OK_USER;
                    }
                }
            }
            
            return RespostaSrv.OK_NEW_USER;
        }  catch (Exception e) {
            System.err.println("Exception: An unexpected error occurred.");
            e.printStackTrace();
            return RespostaSrv.NOK;
        }
    }

    public SecretKey getKeyFromPassword(String password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeySpecException {
        PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray(), salt, 65536); // pass, salt, iterations
        SecretKeyFactory kf = SecretKeyFactory.getInstance("PBEWithHmacSHA256AndAES_128");
        SecretKey key = kf.generateSecret(keySpec);
        return key;
    }

    public String decryptFile(String inputFile, String password) throws Exception {
        // Derive key from password and salt
        SecretKey key = getKeyFromPassword(password, salt);
        
        // Initialize cipher for decryption
        AlgorithmParameters p = AlgorithmParameters.getInstance("PBEWithHmacSHA256AndAES_128");
        p.init(algParam);
        Cipher cipher = Cipher.getInstance("PBEWithHmacSHA256AndAES_128");
        cipher.init(Cipher.DECRYPT_MODE, key, p);

        // Read encrypted content from the file
        byte[] encryptedBytes;
        try (FileInputStream fis = new FileInputStream(inputFile)) {
            encryptedBytes = fis.readAllBytes();
        }

        // Decrypt the encrypted bytes
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

        // Convert decrypted bytes to string
        return new String(decryptedBytes, "UTF-8");
    }

    public void addUser(String fromClientUsr, String publicKey, String password) throws Exception {
        // Get the user files

        String decryptedContent = "";
        File file = new File(USERS_FILE);
        if (!file.exists()) {
            file.createNewFile();
        } else {
            // Decrypt the contents of the file into a string
            decryptedContent = decryptFile(USERS_FILE, password);
        }

        // Add the new line to the decrypted content
        decryptedContent += fromClientUsr + ":" + publicKey + "\n";

        // Derive secret key from password
        SecretKey key = getKeyFromPassword(password, salt);

        // Initialize cipher for encryption
        Cipher c = Cipher.getInstance("PBEWithHmacSHA256AndAES_128");
        c.init(Cipher.ENCRYPT_MODE, key);
        algParam = c.getParameters().getEncoded();

        // Encrypt user credentials and public key
        byte[] encryptedData = c.doFinal(decryptedContent.getBytes("UTF-8"));

        // Write encrypted data to the file
        try (FileOutputStream fos = new FileOutputStream(USERS_FILE)) {
            fos.write(encryptedData);
        } catch (IOException e) {
            System.out.println("Error adding the new user.");
            e.printStackTrace();
        }

        // Guardar os alg param
        try {
            StringBuilder stringBuilder = new StringBuilder();
            BufferedReader reader = new BufferedReader(new FileReader(VARIABLES));
            String line = reader.readLine();

            for (byte b : algParam) {
                stringBuilder.append(b);
                stringBuilder.append(" ");
            }
            
            stringBuilder.append("\n");

            // Append the rest of the lines
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
                stringBuilder.append("\n"); // Add newline character
            }
            reader.close();

            // Write the modified content back to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(VARIABLES));
            writer.write(stringBuilder.toString());
            writer.close();
        } catch (Exception e) {
            System.out.println("Error reading variables file.");
            e.printStackTrace();
        }

        System.out.println("New user registered!" + fromClientUsr);
        activeUsers.add(fromClientUsr);
    }

    public String getUserCertificate(String fromClientUsr, String password) throws IOException {
        String file = "";
        try {
            file = decryptFile(USERS_FILE, password);
        } catch (Exception e) {
            System.out.println("Error decrypting file");
        }
        
        //Scanner a assumir que o username  não contem : nem ,
        Scanner myReader = new Scanner(file);
        myReader.useDelimiter("[:\\n]"); 
        while(myReader.hasNext()) {
            String userName = myReader.next();
            if(userName.equals(fromClientUsr)) {
                String certificatePath = myReader.next();
                myReader.close();
                return certificatePath;
            }
            myReader.next();
        }

        myReader.close();
        return null;
    }
    
    /**
     * Handles client disconnection.
     * Removes the specified sensor device from the list of logged-in devices.
     * @param curSensor The sensor device to be disconnected.
     */
    public void handleClientDisconnect(SensorDevice curSensor){
        loggedInDevices.remove(curSensor);
    }

    /**
     * Handles device ID verification.
     * Checks if the provided device ID is already logged in.
     * @param deviceCheck The sensor device to be verified.
     * @return Response indicating the status of the device ID verification process.
     */
    public RespostaSrv handleDevId(SensorDevice deviceCheck){
        for (SensorDevice i : loggedInDevices) {
            if (i.equals(deviceCheck)) {
                return RespostaSrv.NOK_DEVID;
            }
        }
        loggedInDevices.add(deviceCheck);
        return RespostaSrv.OK_DEVID;
    }

    /**
     * Creates a new domain.
     * Registers a new domain with the specified name and owner.
     * @param domainName The name of the new domain.
     * @param curSensor The sensor device creating the domain.
     * @return Response indicating the status of the domain creation process.
     * @throws IOException If an I/O error occurs.
     */
    public RespostaSrv createDomain(String domainName, SensorDevice curSensor) throws IOException{

        if(domains.containsKey(domainName)){
            return RespostaSrv.NOK;
        }

        Domain newDomain = new Domain(domainName, curSensor.getUserId());
        domains.put(domainName, newDomain);
        addDomainToFile(domainName, curSensor.getUserId());

        return RespostaSrv.OK;
    }
    
    private void addDomainToFile(String domainName, String owner) throws IOException{
        File file = new File(DOMAINS_FILE);
        FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
        BufferedWriter bw = new BufferedWriter(fw);

        bw.append(domainName + ":" + owner + System.lineSeparator() + System.lineSeparator());
        bw.close();
    }

    public RespostaSrv addUserToDomain(String user1, String domainName, SensorDevice curSensor) throws IOException{
        // Caso em que o utilizador (user1) não existe
        if(!activeUsers.contains(user1)){
            return RespostaSrv.NOUSER;
        }

        if(!domains.containsKey(domainName)){
            return RespostaSrv.NODM;
        } 

        Domain domain = domains.get(domainName);
        if(!domain.checkOwner(curSensor.getUserId())){
            return RespostaSrv.NOPERM;
        }

        if(domain.checkUser(user1)){
            return RespostaSrv.NOK;
        }

        domain.addUser(user1);
        addUserToFile(domainName, user1);

        return RespostaSrv.OK;
    }

    private void addUserToFile(String domainName, String user1) throws IOException {
        // Create a File object representing the file
        File file = new File(DOMAINS_FILE);
        // Read the content of the file into a StringBuilder
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader reader = new BufferedReader(new FileReader(file.getAbsoluteFile()));
        String line;
        boolean foundWord = false;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
            // Search for the specific word in the line
            if (!foundWord && line.split(":")[0].equals(domainName)) {
                // Append the content after the specific word
                stringBuilder.append(","+user1);
                foundWord = true;
            }
            stringBuilder.append(System.lineSeparator());
        }
        reader.close();

        // Write the modified content back to the file
        BufferedWriter writer = new BufferedWriter(new FileWriter(file.getAbsoluteFile()));
        writer.write(stringBuilder.toString());
        writer.close();
    }

    public void registerDomainKey(String domainName, byte[] domainKey, String user) throws IOException {
        try {
            File file = new File("./FicheirosServidor/dom" + domainName + ".txt");
            file.createNewFile();
            FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
            BufferedWriter bw = new BufferedWriter(fw);
            
            String encodedKey = Base64.getEncoder().encodeToString(domainKey);
            // Append the user, domainKey, and a newline character to the file
            bw.append(user + ":" + encodedKey + "\n");
            bw.close();
        } catch (Exception e) {
            System.out.println("Error registing the domain key: " + e.getMessage());
        }
    }
    
    /**
    * Registers a device in a domain and updates the domains file.
    * Adds the provided sensor device to the specified domain and updates the domains file accordingly.
    * @param domainName The name of the domain to add the device to.
    * @param curSensor The sensor device to be registered.
    * @return Response indicating the status of the device registration process.
    * @throws IOException If an I/O error occurs.
    */
    public RespostaSrv registerDevice(String domainName, SensorDevice curSensor) throws IOException{

        if(!domains.containsKey(domainName)){
            return RespostaSrv.NODM;
        } 

        Domain domain = domains.get(domainName);
        if(!domain.checkUser(curSensor.getUserId())){
            return RespostaSrv.NOPERM;
        }

        if(domain.checkDevice(curSensor)){
            return RespostaSrv.NOK;
        }

        activeDevices.add(curSensor.toString());
        domain.addDevice(curSensor);
        addDeviceToFile(domainName, curSensor);
        
        return RespostaSrv.OK;
    }

    /**
    * Adds a device to the domains file.
    * Updates the domains file with information about the newly added device in the specified domain.
    * @param domainName The name of the domain to which the device belongs.
    * @param curSensor The sensor device to be added.
    * @throws IOException If an I/O error occurs.
    */
    private void addDeviceToFile(String domainName, SensorDevice curSensor) throws IOException {
        // Create a File object representing the file
        File file = new File(DOMAINS_FILE);
        // Read the content of the file into a StringBuilder
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader reader = new BufferedReader(new FileReader(file.getAbsoluteFile()));
        String line;
        boolean foundWord = false;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
            
            // Search for the specific word in the line
            if (!foundWord && line.split(":")[0].equals(domainName)) {
                // Append the content after the specific word
                stringBuilder.append(System.lineSeparator());
                line = reader.readLine();
                stringBuilder.append(line).append(curSensor.toString() + ",");
                foundWord = true;
            }
            stringBuilder.append(System.lineSeparator());
        }
        reader.close();

        // Write the modified content back to the file
        BufferedWriter writer = new BufferedWriter(new FileWriter(file.getAbsoluteFile()));
        writer.write(stringBuilder.toString());
        writer.close();
    }
    
    /**
    * Sends temperature data from a sensor device and updates the temperature file.
    * Parses the provided temperature data, associates it with the specified sensor device, and updates the temperature file with the new temperature information.
    * @param temperature The temperature data to be sent.
    * @param curSensor The sensor device sending the temperature data.
    * @return Response indicating the status of the temperature sending process.
     * @throws Exception 
    */
    public RespostaSrv sendTemperature(String[] temperatures, SensorDevice curSensor) throws Exception{

        String[] domainsName = getDomainsName(curSensor.getUserId(), curSensor.getDeviceId());

        // 1. Guardar a temperatura.
        try {

            String content = null;

            StringBuilder stringBuilder = new StringBuilder();
            boolean foundWord = false;

            if ((content = verifyHMACTemperature(TEMP_FILE)) != null) {

                // Process the content of the file
                String wordToSearch = curSensor.toString();
                BufferedReader reader = new BufferedReader(new StringReader(content));
                String line;
                while ((line = reader.readLine()) != null) {
                    // Search for the specific word in the line
                    if (!foundWord && line.contains(wordToSearch)) {
                        // Substitui caso seja uma temperatura diferente no mesmo device
                        stringBuilder.append(curSensor.toString());
                        for (int i = 0; i < domainsName.length; i++) {
                            stringBuilder.append(",").append(domainsName[i]).append(":").append(temperatures[i]);
                        }
                        foundWord = true;
                    } else {
                        stringBuilder.append(line);
                    }
    
                    stringBuilder.append(System.lineSeparator());
                }
                reader.close();
            }
            
            // Caso não tenha encontrado, significa que é a primeira temperatura do device
            if (!foundWord) {
                stringBuilder.append(curSensor.toString());
                for (int i = 0; i < domainsName.length; i++) {
                    stringBuilder.append(",").append(domainsName[i]).append(":").append(temperatures[i]);
                }
                stringBuilder.append(System.lineSeparator());
            }

            String data = stringBuilder.toString();

            // Concatenate the hashed content and HMAC
            FileOutputStream fos = new FileOutputStream(TEMP_FILE);
            ObjectOutputStream outputStream = new ObjectOutputStream(fos);
            outputStream.writeObject(data);
            outputStream.writeObject(currHMAC);
            updateHMACInVariablesFile();
            fos.close();

            temps.add(curSensor.toString());
            System.out.println("Temperature added successfully.");
            return RespostaSrv.OK;
        } catch (IOException e) {
            System.err.println("An error occurred while processing temperatures.");
            e.printStackTrace();
            return RespostaSrv.NOK;
        }
    } 
    
    private void updateHMACInVariablesFile() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(VARIABLES));
            StringBuilder stringBuilder = new StringBuilder();
            int lineNumber = 1;
            // Read the lines
            String line;
            while ((line = reader.readLine()) != null || lineNumber == 2) {
                if (lineNumber == 2) {
                    for (byte b : currHMAC) {
                        stringBuilder.append(b);
                        stringBuilder.append(" ");
                    }
                } else {
                    stringBuilder.append(line);
                }
                stringBuilder.append(System.lineSeparator());
                lineNumber++;
            }
            reader.close();

            // Write the modified content back to the file
            BufferedWriter writer = new BufferedWriter(new FileWriter(VARIABLES));
            writer.write(stringBuilder.toString());
            writer.close();
        } catch (IOException e) {
            System.err.println("An error occurred while updating HMAC in VARIABLES file.");
            e.printStackTrace();
        }
    }

    /**
    * Sends an image from a sensor device and updates the image storage.
    * Stores the provided image data associated with the specified sensor device, 
    * updating the image storage with the new image information.
    * @param filename The name of the image file.
    * @param filesize The size of the image file.
    * @param fileBytes The byte array containing the image data.
    * @param curSensor The sensor device sending the image.
    * @return Response indicating the status of the image sending process.
    */
    public RespostaSrv sendImage(String filename, long filesize, String[] fileBytes, SensorDevice curSensor){
        //Trocar fileBytes para String[]
        
        String[] domainsName = getDomainsName(curSensor.getUserId(), curSensor.getDeviceId());

        try{
            // 1. Fazer as verificações
            if (filesize <= 0 || !filename.endsWith(".jpg") || filename.length() <= 4 || fileBytes.length <= 0) {
                return RespostaSrv.NOK;
            }

            // 2. Guardar os dados da imagem em algum sitio, ligado a este dispositivo, substituindo o anterior.
            File myObj = null;
            for (int i = 0; i < domainsName.length; i++) {
                try {
                    myObj = new File("./FicheirosServidor/" + domainsName[i] + "," + curSensor.getUserId()+ "," + curSensor.getDeviceId() + "," + filename);
                    if (myObj.exists()){
                        myObj.delete();
                    }
                    myObj.createNewFile();

                    // Recalculate HMAC for the updated content
                    byte[] actualFile = Base64.getDecoder().decode(fileBytes[i]);

                    try (FileOutputStream fos = new FileOutputStream(myObj); ObjectOutputStream outputStream = new ObjectOutputStream(fos)) {
                        outputStream.writeObject(actualFile);
                        outputStream.writeObject(currHMAC);
                    }
                } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                }
            }

            images.put(curSensor.toString(), myObj);
            System.out.println("Imagem adicionada com: " + curSensor);

            return RespostaSrv.OK;
        } catch (Exception e) {
            System.out.println("Error getting image.");
            e.printStackTrace();
            return RespostaSrv.NOK;
        }
    }

    /**
    * Checks if temperature data is available for a specified domain.
    * Verifies if temperature data exists for any sensor device within the specified domain.
    * @param domainName The name of the domain to check for temperature data.
    * @param curSensor The sensor device requesting temperature data.
    * @return Response indicating the status of the temperature data availability check.
    */
    public RespostaSrv checkReceiveTemperature(String domainName, SensorDevice curSensor){

        try {
            // 1. Verificar se o domínio existe;
            if(!domains.containsKey(domainName)){
                return RespostaSrv.NODM;
            } 
    
            // 2. Verificar se o utilizador curSensor tem permissões;
            Domain curDomain = domains.get(domainName);
            if(!curDomain.checkUser(curSensor.getUserId())){
                return RespostaSrv.NOPERM;
            }
    
            // 3. Verificar se o dm tem temperaturas (se não tiver manda NODATA);
            boolean hasData = false;
            List<SensorDevice> devices = curDomain.getDevices();
            
            for (SensorDevice device : devices) {
                if(temps.contains(device.toString())){
                    hasData = true;
                    break;
                }
            }
    
            if(!hasData){
                return RespostaSrv.NODATA;
            }
    
            return RespostaSrv.OK;
        } catch (Exception e) {
            System.err.println("Erro ao verificar se existe temperatura.");
            e.printStackTrace();
            return RespostaSrv.NOK;
        }
    }

    /**
    * Retrieves temperature data for a specified domain.
    * Retrieves temperature data associated with sensor devices within the specified domain 
    * and returns the data in byte array format.
    * @param domainName The name of the domain to retrieve temperature data from.
    * @return A byte array containing the temperature data for the specified domain, or null if no data is available.
     * @throws Exception 
    */
    public byte[] receiveTemperature(String domainName) throws Exception{

        byte[] byteArray = null;

        try {

            String content;

            // Verify the HMAC before processing the file content
            if ((content = verifyHMACTemperature(TEMP_FILE)) == null) {
                System.out.println("HMAC verification failed for TEMP_FILE.");
                return null;
            }

            // Process the content and filter data for the specified domain
            StringBuilder stringBuilder = new StringBuilder();
            for (String line : content.split("\n")) {
                String[] doms = line.split(",");    //user:id,dom1:tem1,dom2:tem2
                for (int i = 1; i < doms.length; i++) {
                    if (doms[i].startsWith(domainName)) {
                        stringBuilder.append(doms[0]).append(",").append(doms[i]).append(System.lineSeparator());
                    }
                }
            }
            
            // Write the modified content back to the file
            File temporaryFile = File.createTempFile("tempFile", ".txt");

            BufferedWriter writer = new BufferedWriter(new FileWriter(temporaryFile.getAbsoluteFile()));
            writer.write(stringBuilder.toString());
            writer.close();

            byteArray = Files.readAllBytes(temporaryFile.toPath());

            temporaryFile.deleteOnExit();
        } catch (Exception e) {
            System.out.println("Erro ao tranformar o ficheiro de temperatura em byte[]");
            e.printStackTrace();
        }

        return byteArray;
    }

    /**
    * Checks if an image is available for a specified sensor device.
    * Verifies if an image is available for the specified sensor device within the given domain.
    * @param ids The concatenated string containing the user ID and device ID separated by a colon.
    * @param curSensor The sensor device requesting the image.
    * @return Response indicating the status of image availability for the specified sensor device.
    */
    public RespostaSrv checkReceiveImage(String ids, SensorDevice curSensor){
        // 1. Verificar se o devId existe
        String userId;
        int devId;
        try{
            userId = ids.split(":")[0];
            devId = Integer.parseInt(ids.split(":")[1]);
        } catch (Exception e ){
            return RespostaSrv.NOK;    // Mandar um NOK porque o imput está mal
        } 

        SensorDevice wantedDevice = new SensorDevice(userId, devId);
        if(!activeDevices.contains(wantedDevice.toString())){
            return RespostaSrv.NOID;
        }

        // 2. Verificar se o utilizador curSensor tem permissões
        boolean hasPerms = false;
        Collection<Domain> allDomains = domains.values();
        for (Domain domain : allDomains) {
            if(domain.checkDevice(wantedDevice)){
                if(domain.checkUser(curSensor.getUserId())){
                    hasPerms = true;
                    break;
                }
            }
        }
        if (!hasPerms) {
            return RespostaSrv.NOPERM;
        }

        // 3. Verificar se o devId publicou dados
        if (!images.containsKey(wantedDevice.toString())) {
            return RespostaSrv.NODATA;
        }

        return RespostaSrv.OK; 
    }

    /**
    * Retrieves an image associated with a specified sensor device.
    * Retrieves the image data associated with the specified sensor device and returns it as a byte array.
    * @param ids The concatenated string containing the user ID and device ID separated by a colon.
    * @return A byte array containing the image data for the specified sensor device, or null if no image is available.
    */
    public byte[] receiveImage(String ids){
        byte[] byteArray = null;
        String userId = ids.split(":")[0];
        int devId = Integer.parseInt(ids.split(":")[1]);

        SensorDevice wantedDevice = new SensorDevice(userId, devId);

        try {
            if ((byteArray = verifyHMACImage(images.get(wantedDevice.toString()).toString())) == null) {
                System.out.println("HMAC verification failed for the image.");
                return null;
            }
        } catch (Exception e) {
            System.out.println("Erro ao tranformar a imagem em byte[]");
            e.printStackTrace();
        }
        
        return byteArray;
    }

    /**
    * Retrieves the filename associated with a specified sensor device's image.
    * Retrieves the filename of the image associated with the specified sensor device and returns it as a string.
    * @param ids The concatenated string containing the user ID and device ID separated by a colon.
    * @return The filename of the image for the specified sensor device, or an empty string if no image is available.
    */
    public String receiveImageName(String ids){
        String filename = "";

        try {
            String fullFileName = images.get(ids).getName();
            // Find the index of the second comma
            filename = fullFileName.split(",")[3];
        } catch (Exception e) {
            System.out.println("Erro");
            e.printStackTrace();
        }

        return filename;
    }

    public RespostaSrv checkDomains(SensorDevice curSensor) {
        if(getDomainsName(curSensor.getUserId(), curSensor.getDeviceId()).length == 0){
            return RespostaSrv.NODATA;
        }

        return RespostaSrv.OK; 
    }

    public String[] getDomainsName(String userId){
        List<String> retVal = new ArrayList<String>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(DOMAINS_FILE));
            String line = reader.readLine(); 
            boolean lookingDomain = true;
            while (line != null) {  
                if(lookingDomain){
                    String[] domain = line.split(":");
                    String[] users = domain[1].split(",");
                    for (int i = 1; i < users.length; i++) {
                        if(userId.equals(users[i])) {
                            retVal.add(domain[0]);
                        }
                    }
                }
                line = reader.readLine();
                lookingDomain = !lookingDomain;
            }
            reader.close();
        } catch (Exception e) {
            System.out.println("Error getting the domain key: " + e.getMessage());
        }
        
        return retVal.toArray(new String[0]);
    }

    public String[] getDomainsName(String userId, int devId){
        List<String> retVal = new ArrayList<String>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(DOMAINS_FILE));
            String line = reader.readLine(); 
            boolean lookingDomain = true;
            String lastDomain = "";
            while (line != null) {  
                if(lookingDomain){
                    String[] domain = line.split(":");
                    lastDomain = domain[0];
                } else {
                    String[] sensors = line.split(",");
                    for (String sensor : sensors) {
                        if(sensor.contains(":")){
                            String curUserId = sensor.split(":")[0];
                            int curDevId = Integer.parseInt(sensor.split(":")[1]);
                            if(userId.equals(curUserId) && devId == curDevId) {
                                retVal.add(lastDomain);
                                break;  //NOTA talvez este break saia do while em vez de sair do for, idk
                            }
                        }
                    }
                }
                line = reader.readLine();
                lookingDomain = !lookingDomain;
            }
            reader.close();
        } catch (Exception e) {
            System.out.println("Error getting the domain key: " + e.getMessage());
        }
        
        return retVal.toArray(new String[0]);
    }

    public byte[] getDomainKey(String domainName, String user) throws Exception{
        String filename = "./FicheirosServidor/dom" + domainName + ".txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts[0].equals(user)) {
                    String encodedKey = parts[1];
                    return Base64.getDecoder().decode(encodedKey);  
                }
            }
        } catch (Exception e) {
            System.out.println("Error getting the domain key: " + e.getMessage());
        }
        throw new Exception("User name not found in the file.");
    }

    public String[] getDomainKeys(String userId, int devId){
        String[] domains = getDomainsName(userId, devId);
        String[] domainKeys = new String[domains.length];
        for (int i = 0; i < domainKeys.length; i++) {
            try {
                domainKeys[i] = Base64.getEncoder().encodeToString(getDomainKey(domains[i], userId));
            } catch (Exception e){
                System.out.println("Error getting the domain keys.");
            }
        }
        return domainKeys;
    }

    public String getCommonDomainName(String currUser, String userId) {
		String[] user1Domains = getDomainsName(currUser);
		String[] user2Domains = getDomainsName(userId);

        for (String domain2 : user2Domains) {
            for (String domain1 : user1Domains) {
                if (domain2.equals(domain1)) {
                    return domain2;
                }
            }
        }
        return null;
	}
    
    // Function to verify HMAC for the content
    public String verifyHMACTemperature(String filename) {
        try {
            FileInputStream fis = new FileInputStream(filename);
            ObjectInputStream ois = new ObjectInputStream(fis);

            Object o = ois.readObject();
            if (!(o instanceof String)) {
                System.out.println("error");
                System.exit(-1);
            }

            String data = (String) o;
            byte[] fileHMAC = (byte[]) ois.readObject();
            ois.close();
            fis.close();
        
            // Compare the received HMAC with provided currentHMAC
            return MessageDigest.isEqual(fileHMAC, currHMAC) ? data : null;
        } catch (Exception e){
            return null;
        }
    }

    public byte[] verifyHMACImage(String filename) {
        try {
            FileInputStream fis = new FileInputStream(filename);
            ObjectInputStream ois = new ObjectInputStream(fis);

            Object o = ois.readObject();

            byte[] data = (byte[]) o;
            byte[] fileHMAC = (byte[]) ois.readObject();
            ois.close();
            fis.close();
        
            // Compare the received HMAC with provided currentHMAC
            return MessageDigest.isEqual(fileHMAC, currHMAC) ? data : null;
        } catch (Exception e){
            return null;
        }
    }

}
