import java.util.ArrayList;
import java.util.List;

/**
 * The Domain class represents a domain with its associated properties such as domain name, owner, users, and devices.
 */
public class Domain {

    private String domainName;
    private String owner;
    private List<String> users;
    private List<SensorDevice> devices;

    /**
     * Constructs a new Domain object with the specified domain name and owner.
     * @param domainName The name of the domain.
     * @param owner The owner of the domain.
     */
    public Domain(String domainName, String owner){
        this.domainName = domainName;
        this.owner = owner;
        this.users = new ArrayList<>();
        this.devices = new ArrayList<SensorDevice>();
    }

    public String getOwner(){
        return this.owner;
    }

    /**
     * Checks if the provided user is the owner of the domain.
     * @param user The user to check.
     * @return True if the user is the owner, false otherwise.
     */
    public boolean checkOwner(String user){
        return this.owner.equals(user);
    }

    /**
     * Checks if the provided user is a member of the domain.
     * @param user The user to check.
     * @return True if the user is a member, false otherwise.
     */
    public boolean checkUser(String user){
        return this.users.contains(user);
    }

    /**
     * Checks if the provided sensor device is associated with the domain.
     * @param sensor The sensor device to check.
     * @return True if the device is associated, false otherwise.
     */
    public boolean checkDevice(SensorDevice sensor){
        return this.devices.contains(sensor);
    }

    /**
     * Retrieves the name of the domain.
     * @return The name of the domain.
     */
    public String getDomainName(){
        return new String(this.domainName);
    }

    /**
     * Retrieves a list of users in the domain.
     * @return A list of users in the domain.
     */
    public List<String> getUsers(){
        List<String> clonedUsersList = new ArrayList<>(users);
        return clonedUsersList;
    }

    /**
     * Retrieves a list of sensor devices associated with the domain.
     * @return A list of sensor devices associated with the domain.
     */
    public List<SensorDevice> getDevices(){
        List<SensorDevice> clonedDevicesList = new ArrayList<>(devices);
        return clonedDevicesList;
    }

    /**
     * Adds a user to the domain if they are not already a member.
     * @param user The user to add.
     * @requires Conditions to be handled before calling this method.
     */
    public void addUser(String user){
        if(!this.users.contains(user)){
            this.users.add(user);
        }
    }

    /**
     * Adds a sensor device to the domain if it is not already associated.
     * @param device The sensor device to add.
     * @requires Conditions to be handled before calling this method.
     */
    public void addDevice(SensorDevice device){
        if(!this.devices.contains(device)){
            this.devices.add(device);
        }
    }
}
