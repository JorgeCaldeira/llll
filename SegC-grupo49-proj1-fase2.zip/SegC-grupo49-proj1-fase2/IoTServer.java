import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.Base64;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.ByteArrayInputStream;

import javax.net.ServerSocketFactory;
import javax.net.ssl.*;

/**
 * The IoTServer class represents a server application for managing IoT devices and data.
 * It listens for incoming connections from IoT devices, processes their requests, and interacts with a database.
 */
public class IoTServer {
    
    public static final int DEFAULT_PORT = 12345;

    /**
     * The main method of the IoTServer class.
     * It initializes the server, sets up the database, and starts listening for client connections.
     * @param args Command-line arguments. The first argument (if provided) specifies the port number.
     * @throws Exception 
     */
    public static void main(String[] args) throws Exception {

        int port = DEFAULT_PORT;
        if(args.length == 5){
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException ex){
                System.out.println("Error: The port must be a number. "+ex.getMessage());
                return;
            }
			args[0] = args[1];
			args[1] = args[2];
			args[2] = args[3];
			args[3] = args[4];
        } else if (args.length != 4) {
			System.out.println("Something is missing\nUsage: IoTServer <port> <password-cifra> <keystore> <password-keystore> <2FA-APIKey>");
            return;
        }

        String passwordCifra = args[0];
        String keystorePath = args[1];
        String keystorePassword = args[2];
        String apikey = args[3];

        Database database = new Database(passwordCifra);
        database.restoreDatabaseFromFiles(passwordCifra);
        
        System.setProperty("javax.net.ssl.keyStore", keystorePath); //./FicheirosServidor/keystore.server
        System.setProperty("javax.net.ssl.keyStorePassword", keystorePassword); // passserver

        try {

            ServerSocketFactory sslServerSocketFactory = SSLServerSocketFactory.getDefault();

            try (SSLServerSocket srvSocket = (SSLServerSocket) sslServerSocketFactory.createServerSocket(port)) {
                System.out.println("Server Started");
                while(true) {
                    SSLSocket clientSocket = (SSLSocket) srvSocket.accept();
                    Threads newThread = new Threads(clientSocket, database, passwordCifra, apikey);
                    new Thread(newThread).start();
                }
            }
        } catch (Exception e) {
            System.err.println("Error starting server: " + e.getMessage());
            e.printStackTrace();
        }
	}
}

/**
 * The Threads class implements a runnable thread that handles client connections for the IoT server.
 * Each instance of Threads is responsible for managing communication with a single client.
 */
class Threads implements Runnable  {

    private byte[] temperatureFile;
    private byte[] imageFile;
    private String currDomainName;
    private String currUser;

	private SSLSocket cliSocket;
    private String nameFile;
    private String passwordCifra;
    private String apikey;

    ObjectOutputStream out;
    ObjectInputStream in;
    Database database;
    SensorDevice curSensor;
    SecureRandom secureRandom;
    String[] userDomains;

    private static final String CHECK_DEVICE_FILE = "./FicheirosServidor/dev_file.txt";
	
    /**
     * Constructs a new Threads object with the specified client socket and database.
     * @param socket The client socket.
     * @param database The database instance used by the server.
     */
	Threads(SSLSocket socket, Database database, String passwordCifra, String apikey) {
		this.cliSocket = socket;
        this.database = database;
        this.passwordCifra = passwordCifra;
        this.apikey = apikey;
	}
	
    /**
     * Runs the thread, handling communication with the client.
     */
	public void run() {
        
        try{
            // Cria forma de comunicar com o cliente
            try {
                out = new ObjectOutputStream(cliSocket.getOutputStream());
                in = new ObjectInputStream(cliSocket.getInputStream());
                secureRandom = new SecureRandom();
            } catch (IOException e) {
                System.out.println("Erro ao criar os objects no servidor.");
                e.printStackTrace();
            }

            String userEmail = "";
            Comando cmd = null;
            RespostaSrv resposta = null;

            //4.2
            //4.2.1
            // Autenticação do cliente
            try {

                userEmail = (String) in.readObject();
                resposta = database.handleClientConnection(userEmail, passwordCifra);
                
                byte[] nonce = new byte[8];
                secureRandom.nextBytes(nonce);

                out.writeObject(resposta);
                out.writeObject(nonce);
                out.flush();

                switch (resposta) {
                    case OK_USER:
                        // Recive the private key with the signature of the user
                        byte[] signature = (byte[]) in.readObject();
                   
                        Signature assinaturaVerificadora = Signature.getInstance("SHA256withRSA");   
       
                        // Load the certificate file
                        FileInputStream fis = new FileInputStream(database.getUserCertificate(userEmail, passwordCifra));

                        // Initialize the CertificateFactory
                        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");

                        // Generate the certificate from the file input stream
                        Certificate cert = certFactory.generateCertificate(fis);

                        // Close the file input stream
                        fis.close();
                        
                        PublicKey publicKey = cert.getPublicKey();
                        assinaturaVerificadora.initVerify(publicKey); // Iniciar a assinatura com a chave pública que obtemos do certificado do user
                        assinaturaVerificadora.update(nonce); // Dar update à signature com o nonce do cliente
                        
                        if(!assinaturaVerificadora.verify(signature)) { // Ver se a assinatura do cliente é válida
                            out.writeObject(RespostaSrv.NOK);
                            out.flush();
                            closeThread();
                        }

                        out.writeObject(RespostaSrv.OK);
                        out.flush();
                        
                        break;
                    case OK_NEW_USER:
                        byte[] clientNonce = (byte[]) in.readObject();

                        if (!MessageDigest.isEqual(clientNonce, nonce)){
                            out.writeObject(RespostaSrv.NOK);
                            out.flush();
                            closeThread();
                        }
                        
                        signature = (byte[]) in.readObject();
                        byte[] certBytes= (byte[]) in.readObject();
                        CertificateFactory cf   = CertificateFactory.getInstance("X.509");
                        cert = cf.generateCertificate(new ByteArrayInputStream(certBytes));
                        publicKey = cert.getPublicKey();
                        assinaturaVerificadora = Signature.getInstance("SHA256withRSA");

                        assinaturaVerificadora.initVerify(publicKey); // Iniciar a assinatura com a chave pública que obtemos do certificado do user
                        assinaturaVerificadora.update(nonce); // Dar update à signature com o nonce do cliente
                        
                        if(!assinaturaVerificadora.verify(signature)) { // Ver se a assinatura do cliente é válida
                            out.writeObject(RespostaSrv.NOK);
                            out.flush();
                            closeThread();
                        }
                        out.writeObject(RespostaSrv.OK);
                        out.flush();
                        String certPath = "./FicheirosServidor/"+(String) in.readObject();
                        database.addUser(userEmail, certPath, passwordCifra); // Buscar o filename usando o alias

                        FileOutputStream fos = new FileOutputStream(certPath);
                        fos.write(cert.getEncoded());
                        fos.close();
                        break;
                    default:
                        System.out.println("Step3 - Error in the server message!");
                        break;
                }
            } catch (Exception e) {
                System.out.println("Erro ao receber as credenciais."+e.getMessage());
                e.printStackTrace();
            }

            //4.2.2 proj2 
            // Autenticação de 2 fatores
            
            boolean c2faComplete = false;
            while(!c2faComplete){
                try {
                    int c2fa = secureRandom.nextInt(100000);
                    URL url = new URL("https://lmpinto.eu.pythonanywhere.com/2FA?e="+userEmail+"&c="+c2fa+"&a="+apikey);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("GET");
                    int responseCode = con.getResponseCode();
                    System.out.println("Response Code: " + responseCode);
                    con.disconnect();
                    if (responseCode == 200) {
                        int userC2fa = (int) in.readObject();
                        if (c2fa == userC2fa){
                            resposta = RespostaSrv.OK_2FA;
                            c2faComplete = true;
                        } else {
                            resposta = RespostaSrv.NOK_2FA;
                        }
                        out.writeObject(resposta);
                        out.flush();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            

            //4.3 proj2
            // 
            int devId = -1;
            byte[] nonce;
            try {
                devId = (int) in.readObject();
                SensorDevice deviceCheck = new SensorDevice(userEmail.split(":")[0], devId);
                resposta = database.handleDevId(deviceCheck);
                out.writeObject(resposta);
                out.flush();
                if (resposta == RespostaSrv.NOK_DEVID) {
                    closeThread();
                }
                nonce = new byte[8];
                secureRandom.nextBytes(nonce);
                out.writeObject(nonce);
                out.flush();
            } catch (ClassNotFoundException | IOException e) {
                System.out.println("Erro ao receber o devid.");
                return;
            }

            curSensor = new SensorDevice(userEmail.split(":")[0], devId);
            
            //passo 5 e 6 do Device
            String fileName = "";
            String fileDirectory = "";
            try {
                BufferedReader reader = new BufferedReader(new FileReader(CHECK_DEVICE_FILE));
                fileName = reader.readLine();
                fileDirectory = reader.readLine();
                reader.close();
            } catch (Exception e) {
                System.out.println("Erro ao obter ficheiros de verificação.");
            }
            
            try {
                // Buscar o ficheiro IoTDevice
                File executableFile = new File(fileDirectory, fileName);

                // Obter uma array de bytes do ficheiro
                byte[] fileBytes = Files.readAllBytes(executableFile.toPath());

                // Criar um novo array de bytes para concatenar o ficheiro com o nonce
                int fileLength = fileBytes.length;
                int nonceLength = nonce.length;
                byte[] concatenatedByteArray = new byte[fileLength + nonceLength];
                System.arraycopy(fileBytes, 0, concatenatedByteArray, 0, fileLength);
                System.arraycopy(nonce, 0, concatenatedByteArray, fileLength, nonceLength);

                // Criar o MessageDisgest para criar o hash
                MessageDigest digest = MessageDigest.getInstance("SHA-256");
                byte[] encodedhash = digest.digest(concatenatedByteArray);

                // Converter os bytes para uma string hexadecimal
                StringBuilder hexString = new StringBuilder();
                for (byte b : encodedhash) {
                    String hex = Integer.toHexString(0xff & b);
                    if (hex.length() == 1) {
                        hexString.append('0');
                    }
                    hexString.append(hex);
                }

                String realFileHash = hexString.toString();
                String fileHash = (String) in.readObject();
                
                if(fileHash.equals(realFileHash)){
                    out.writeObject(RespostaSrv.OK_TESTED);
                    out.flush();
                } else {
                    out.writeObject(RespostaSrv.NOK_TESTED);
                    out.flush();
                    closeThread();
                }
            } catch (Exception e) {
                System.out.println("Erro na verificação.");
            }
            
            do {
                try{
                    cmd = (Comando) in.readObject(); 
                    if(cmd != Comando.QUIT){
                        resposta = handleClientInput(cmd);
                        out.writeObject(resposta);
                        out.flush();
                    }
                    if(cmd == Comando.RT && resposta == RespostaSrv.OK){
                        out.writeObject(database.getDomainKey(currDomainName, curSensor.getUserId()));  //chave do dominio cifrada com a chave publica do user 
                        out.writeLong(temperatureFile.length);
                        out.write(temperatureFile, 0, temperatureFile.length);
                        out.flush();

                    } else if (cmd == Comando.RI && resposta == RespostaSrv.OK){ 
                        String validDomainName = database.getCommonDomainName(currUser, curSensor.getUserId());
                        out.writeObject(database.getDomainKey(validDomainName, curSensor.getUserId()));  //chave do dominio cifrada com a chave publica do user 
                        out.writeLong(imageFile.length);
                        out.writeObject(nameFile);
                        out.write(imageFile, 0, imageFile.length);
                        out.flush();
                    } else if (cmd == Comando.ADD && resposta == RespostaSrv.OK){
                        long fileSize = (long) in.readLong();
                        byte[] domainKey = new byte[(int) fileSize];
                        in.readFully(domainKey, 0, (int) fileSize);
                        
                        database.registerDomainKey(currDomainName, domainKey, currUser);
                    } else if (cmd == Comando.MYDOMAINS && resposta == RespostaSrv.OK){
                        out.writeObject(userDomains);
                        out.flush();
                    }
                } catch (Exception e) {
                    System.out.println("Erro ao receber os comandos do cliente.");
                    return;
                }
                    
            } while (cmd != Comando.QUIT);
        } catch (Exception e) {
            System.out.println("Paragem no servidor.");
        } finally {
            closeThread();
        }
	}

	private void closeThread() {
        try {
            database.handleClientDisconnect(curSensor);
            out.close();
            in.close();
            cliSocket.close();
        } catch (IOException e) {
            System.out.println("Erro ao fechar a Thread.");
            e.printStackTrace();
        }
    }

    /**
     * Handles client input commands and returns the server response.
     * @param cmd The command received from the client.
     * @return The server response to the client command.
     * @throws Exception 
     */
    private RespostaSrv handleClientInput(Comando cmd) throws Exception{
        String clientInfo;
        RespostaSrv serverAsw;
        switch (cmd) {
            case CREATE:
                //criar domínio - utilizador é Owner
                //<dm> - domain name
                clientInfo = (String) in.readObject(); 
                return database.createDomain(clientInfo, curSensor);
            case ADD:
                //Adicionar utilizador <user1> ao dominio <dm>
                //<user1> <dm>
                String user1 = (String) in.readObject(); 
                clientInfo = (String) in.readObject(); 
                currDomainName = clientInfo;
                currUser = user1;
                return database.addUserToDomain(user1, clientInfo, curSensor);
            case RD:
                //Registar o Dispositivo atual no domínio <dm>
                //<dm>
                clientInfo = (String) in.readObject(); 
                return database.registerDevice(clientInfo, curSensor);
            case ET:
                //Enviar o valor <float> de Temperatura para o servidor
                //<float>
                String[] domainKeys = database.getDomainKeys(curSensor.getUserId(), curSensor.getDeviceId());
                out.writeObject(domainKeys);
                out.flush();

                String[] temperatures = (String[]) in.readObject();
                return database.sendTemperature(temperatures, curSensor);
            case EI:
                //Enviar Imagem <filename.jpg> para o servidor
                //<filename.jpg>
                domainKeys = database.getDomainKeys(curSensor.getUserId(), curSensor.getDeviceId());
                out.writeObject(domainKeys);
                out.flush();

                String filename = (String) in.readObject();
                //long filesize = (long) in.readObject(); //TODO tirar de hardcoded
                long filesize = 1;
                String[] fileContent = (String[]) in.readObject();
                return database.sendImage(filename, filesize, fileContent, curSensor);
            case RT:
                //Receber as últimas medições de Temperatura de cada dispositivo do dominio <dm>, desde que o _utilizador_ tenha permissões
                //<dm>
                //Check Permissions in the database
                clientInfo = (String) in.readObject();
                currDomainName = clientInfo;
                serverAsw = database.checkReceiveTemperature(clientInfo, curSensor);
                if(serverAsw==RespostaSrv.OK){
                    temperatureFile = database.receiveTemperature(clientInfo);
                } 
                return serverAsw;
            case RI:
                //Receber o ficheiro Imagem do dispositovo <user-id>:<dev_id> do servidor, desde que o _utilizador_ tenha permissões
                //<user-id>:<dev_id>
                //Check Permissions in the database
                clientInfo = (String) in.readObject();
                try {
                    currUser = clientInfo.split(":")[0];
                } catch (Exception e) {
                    System.out.println("Problema a receber o pedido RI por erro do cliente");
                }
                serverAsw = database.checkReceiveImage(clientInfo, curSensor);
                if(serverAsw==RespostaSrv.OK){
                    imageFile = database.receiveImage(clientInfo);
                    nameFile = database.receiveImageName(clientInfo);
                } 
                return serverAsw;
            case MYDOMAINS:
                //imprime a lista de domínios que o dispositivo pertence.
                serverAsw = database.checkDomains(curSensor);
                if(serverAsw==RespostaSrv.OK){
                    userDomains = database.getDomainsName(curSensor.getUserId(), curSensor.getDeviceId());
                }
                return serverAsw;
            default:
                throw new IOException("Erro ao receber o comando do cliente: Comando não reconhecido");
        }
    }

}

