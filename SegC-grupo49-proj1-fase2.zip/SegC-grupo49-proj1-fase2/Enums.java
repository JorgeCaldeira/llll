enum Comando {
    CREATE,
    ADD,
    RD,
    ET,
    EI,
    RT,
    RI,
    MYDOMAINS,
    QUIT
}

enum RespostaSrv {
    OK_NEW_USER,
    OK_USER,
    WRONG_PWD,
    OK_DEVID,
    NOK_DEVID,
    NOK_TESTED,
    OK_TESTED,
    OK,
    NOK,
    NOPERM,
    NODM,
    NOUSER,
    NODATA,
    NOID,
    OK_2FA,
    NOK_2FA
}