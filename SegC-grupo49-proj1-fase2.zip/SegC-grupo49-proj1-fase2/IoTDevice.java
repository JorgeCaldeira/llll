import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.SocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import sun.misc.Signal;
import sun.misc.SignalHandler;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.spec.KeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.InputMismatchException;
import java.util.List;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

/**
 * Represents an IoT device that communicates with a server.
 */
public class IoTDevice {

	private static KeyStore truststore;
	private static KeyStore ks;
	private static String truststorePath;
	private static String keystorePath;
    private static String password_ks;

	private static ObjectOutputStream out;
	private static ObjectInputStream in;
	private static Scanner sc;
	private static SSLSocket clientSocket;

	/**
     * Main method to execute the IoT device.
     *
     * @param args Command line arguments: <serverAddress> <dev-id> <user-id>
	 * @throws Exception 
     */
	public static void main(String[] args) throws Exception {

		// Verificar o número de argumentos
		if (args.length != 6) {
			System.out.println("Something is missing\nUsage: IoTDevice <serverAddress> <truststore> <keystore> <passwordkeystore> <dev-id> <user-id>");
			return;
		}

		// Verificar o serverAddress
		if (args[0].split("\\.").length != 4 || (args[0].contains(":") && args[0].split(":").length != 2)){
			System.out.println("Server Adress has the wrong format, use: x.x.x.x[:port]");
			return;
		}

		String ip = "";
		int port = 0;

		//Ver se é dado o porto
		if (args[0].contains(":")){
			ip = args[0].split(":")[0];
			try {
				port = Integer.parseInt(args[0].split(":")[1]);
			} catch (NumberFormatException ex){
				System.out.println("Erro ao passar o porto, não é um integer.");
				ex.printStackTrace();
			}
		} else {
			ip = args[0].split(":")[0];
			port = 12345;
		}
		
		int devId = 0;

		// Verificar o devId
		try {
			devId = Integer.parseInt(args[4]);
		} catch (NumberFormatException ex){
			System.out.println("Error: The devId must be a number. "+ex.getMessage());
		}

        // Verificar o userId
		if (args[5].contains(":") || args[5].contains(",")){
			System.out.println("The userId must not have the character ':' or ',', please try again.");
			return;
		}

		//Verificar se o userid é um email
		final String EMAIL_REGEX = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		final Pattern pattern = Pattern.compile(EMAIL_REGEX);
		Matcher matcher = pattern.matcher(args[5]);
		if(!matcher.matches()){
			System.out.println("The userId must be a valid email");
			return;
		}

		truststorePath = args[1];
        System.setProperty("javax.net.ssl.trustStore",truststorePath);
        System.setProperty("javax.net.ssl.trustStorePassword", "changeit");

		truststore = KeyStore.getInstance("JKS");

		keystorePath = args[2];
		password_ks = args[3];
        System.setProperty("javax.net.ssl.keyStore", keystorePath);
        System.setProperty("javax.net.ssl.keyStorePassword", password_ks);

		KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());		
		InputStream readStream = new FileInputStream(keystorePath);
		ks.load(readStream, password_ks.toCharArray());

		//4.1
		SocketFactory factory = SSLSocketFactory.getDefault();
		clientSocket = (SSLSocket) factory.createSocket(ip, port);
		
		out = new ObjectOutputStream(clientSocket.getOutputStream());
		in = new ObjectInputStream(clientSocket.getInputStream());
		
		sc = new Scanner(System.in);

		// Adicionar um handle para quando o user usar Ctrl+C
		Signal.handle(new Signal("INT"), new SignalHandler() {
            public void handle(Signal sig) {
                try {
					out.writeObject(Comando.QUIT);
					out.flush();
                    closeClient();
                } catch (IOException e) {
					System.out.println("Error closing the device.");
                    return;
                }
            }
        });

		//4.2
		String userId = args[5];
		RespostaSrv fromServer;
		//4.2.1
		try {
			out.writeObject(userId);
			out.flush();
			fromServer = (RespostaSrv) in.readObject();
			byte[] nonce = new byte[8];
			switch (fromServer) {
				case OK_USER:
					nonce = (byte[]) in.readObject();

					// Read user's private key and certificate
					byte[] signatureBytes = signData(nonce, ks, password_ks);

					out.writeObject(signatureBytes);
					out.flush();
					
					fromServer = (RespostaSrv) in.readObject();
					
					if (fromServer.equals(RespostaSrv.NOK)) {
						closeClient();
						throw new Exception("The client signature was not valid.");
					}
					break;
				case OK_NEW_USER:
					nonce = (byte[]) in.readObject();
					
					// Read user's private key and certificate
					signatureBytes = signData(nonce, ks, password_ks);
					Certificate cert = ks.getCertificate(ks.aliases().nextElement()); 

					// Send nonce, signature, and certificate to the server
					out.writeObject(nonce);
					out.writeObject(signatureBytes);
					out.writeObject(cert.getEncoded());
					out.flush();
					fromServer = (RespostaSrv) in.readObject();
					if (fromServer.equals(RespostaSrv.NOK)) {
						closeClient();
						throw new Exception("The client signature was not valid.");
					} else {
						out.writeObject(ks.aliases().nextElement()+".cer");
                        out.flush();
					}
					break;
				default:
					System.out.println("Step3 - Error in the server message!");
					break;
			}
		} catch (Exception e) {
			System.out.println("There was an error verifying the client. "+e.getMessage());
		}
			
		//passo 4.2.2
		
		boolean c2faComplete = false;
		boolean rcvInt = false;
		int c2fa = -1;
		while(!c2faComplete){
			try {
				System.out.println("Write the number in the email sent to "+userId+".");
				c2fa = sc.nextInt();
				out.writeObject(c2fa);
				out.flush();
				rcvInt = true;
			} catch (InputMismatchException e) {
				System.out.println("Input must be an integer. Please try again.");
				// Clear the scanner buffer to avoid an infinite loop
				sc.nextLine();
				rcvInt = false;
			} catch (Exception e) {
				System.out.println("There was an error when trying to get c2fa."+e.getMessage());
				out.writeObject(-1);
				out.flush();
			}
			
			if(rcvInt){
				fromServer = (RespostaSrv) in.readObject();

				if(fromServer.equals(RespostaSrv.OK_2FA)){
					c2faComplete = true;
				} else if (fromServer.equals(RespostaSrv.NOK_2FA)) {
					System.out.println("Wrong number, resending...");
				} else {
					System.out.println("Error");
				}
			}
		}
		
        // Passo3 e Passo4
        // Enviar o <devid> para o servidor e receber resposta
		out.writeObject(devId);
		out.flush();
		fromServer = (RespostaSrv) in.readObject();
		byte[] nonce = new byte[8];
		switch (fromServer) {
			case NOK_DEVID:
				closeClient();
				System.out.println("The device ID is already in use with this user.");
				return;
			case OK_DEVID:
				nonce = (byte[]) in.readObject();
				break;
			default:
				System.out.println("Step3 - Error in the server message!");
				break;
		}

		// Passo 5
		try {
			// Buscar o ficheiro IoTDevice
			File executableFile = new File("IoTDevice.jar");

			// Obter uma array de bytes do ficheiro
			byte[] fileBytes = Files.readAllBytes(executableFile.toPath());

			// Criar um novo array de bytes para concatenar o ficheiro com o nonce
			int fileLength = fileBytes.length;
			int nonceLength = nonce.length;
			byte[] concatenatedByteArray = new byte[fileLength + nonceLength];
			System.arraycopy(fileBytes, 0, concatenatedByteArray, 0, fileLength);
			System.arraycopy(nonce, 0, concatenatedByteArray, fileLength, nonceLength);

			// Criar o MessageDisgest para criar o hash
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] encodedhash = digest.digest(concatenatedByteArray);

			// Converter os bytes para uma string hexadecimal
			StringBuilder hexString = new StringBuilder();
			for (byte b : encodedhash) {
				String hex = Integer.toHexString(0xff & b);
				if (hex.length() == 1) {
					hexString.append('0');
				}
				hexString.append(hex);
			}

			String hashedValue = hexString.toString();
			out.writeObject(hashedValue);
			out.flush();
		}  catch (Exception e) {
			System.out.println("There was an error when trying to get the IoTDevice file. "+e.getMessage());
		}

		// Passo 6
		fromServer = (RespostaSrv) in.readObject();
		switch (fromServer) {
			case NOK_TESTED:
				closeClient();
				throw new Exception("Application not validated by the server!");
			case OK_TESTED:
				break;
			default:
				System.out.println("Step 6 - Error in the server message!");
				break;
		}

		File directoryDevice = new File("RespostasServidor");
        if (!directoryDevice.exists()) {
            directoryDevice.mkdirs(); 
        }

		// Passo 7
		printPossibleCommands();

		// Passo 8 e 9
		String fullCommand;
		String[] command;
		while(true){
			fullCommand = sc.nextLine();
			command = fullCommand.split(" ");
			switch (command[0]) {
				case "CREATE":
					if (command.length != 2) {
						System.out.println("Something is missing!\nCorrect usage: CREATE <dm>");
						break;
					}
					out.writeObject(Comando.CREATE);
					out.writeObject(command[1]);
					out.flush();
					userCreate(in, out, command[1]);
					break;
				case "ADD":
					if (command.length != 4) {
						System.out.println("Something is missing!\nCorrect usage: ADD <user1> <dm> <password-dominio>");
						break;
					}
					out.writeObject(Comando.ADD);
					out.writeObject(command[1]);
					out.writeObject(command[2]);
					out.flush();
					userAdd(in, out, command[3], command[1], command[2], ks);
					break;
				case "RD":
					if (command.length != 2) {
						System.out.println("Something is missing!\nCorrect usage: RD <dm>");
						break;
					}
					out.writeObject(Comando.RD);
					out.writeObject(command[1]);
					out.flush();
					userRegistDevice(in, out);
					break;
				case "ET":
					if (command.length != 2) {
						System.out.println("Something is missing!\nCorrect usage: ET <float>");
						break;
					}
					out.writeObject(Comando.ET);
					out.flush();
					userSendTempValue(command[1], in, out, ks);
					break;
				case "EI":
					if (command.length != 2) {
						System.out.println("Something is missing!\nCorrect usage: EI <filename.jpg>");
						break;
					}
					out.writeObject(Comando.EI);
					out.flush();
					userSendImage(command[1], in, out, ks);
					break;
				case "RT":
					if (command.length != 2) {
						System.out.println("Something is missing!\nCorrect usage: RT <dm>");
						break;
					}
					out.writeObject(Comando.RT);
					out.writeObject(command[1]);
					out.flush();
					userReceiveTemp(in, out, ks);
					break;
				case "RI":
					if (command.length != 2 || command[1].split(":").length != 2) {
						System.out.println("Something is missing!\nCorrect usage: RI <user-id>:<dev_id>");
						break;
					}
					out.writeObject(Comando.RI);
					out.writeObject(command[1]);
					out.flush();
					userReceiveImage(in, out, ks);
					break;
				case "MYDOMAINS":
					if (command.length != 1){
						System.out.println("Something is wrong!\nCorrect usage: MYDOMAINS");
						break;
					}
					out.writeObject(Comando.MYDOMAINS);
					out.flush();
					userDomains(in, out);
					break;
				default:
					System.out.println("Command not recognised, please insert a valid command.");
					printPossibleCommands();
					break;
			}
		}
	}

	/**
     * Prints possible commands for user interaction.
     */
	private static void printPossibleCommands(){
		System.out.println("CREATE <dm> # Criar domínio - utilizador é Owner\n" + //
						"ADD <user1> <dm> <dmKey> <password-dominio> # Adicionar utilizador <user1> ao domínio <dm>\n" + //
		 				"RD <dm> # Registar o Dispositivo atual no domínio <dm>\n" + //
						"ET <float> # Enviar valor <float> de Temperatura para o servidor.\n" + //
						"EI <filename.jpg> # Enviar Imagem <filename.jpg> para o servidor.\n" + //
						"RT <dm> # Receber as últimas medições de Temperatura de cada" + //
						"dispositivo do domínio <dm>, desde que o utilizador tenha permissões.\n" + //
						"RI <user-id>:<dev_id> # Receber o ficheiro Imagem do dispositivo" + //
						"<user-id>:<dev_id> do servidor, desde que o utilizador tenha permissões\n." + //
						"MYDOMAINS # Receber os dominios a que o utilizador pertence");
	}

	/**
     * Handles user creation response from the server.
     * This method reads the response from the server and prints appropriate messages based on the response.
 	 *
     * @param in  ObjectInputStream for reading server response.
     * @param out ObjectOutputStream for writing to the server.
     * @throws ClassNotFoundException If a class is not found during deserialization.
     * @throws IOException If an I/O error occurs.
     */
	private static void userCreate(ObjectInputStream in, ObjectOutputStream out, String dom) throws ClassNotFoundException, IOException{

		//Adicionar o dominio a uma lista de dominios a que ainda temos de criar

		RespostaSrv fromServer = (RespostaSrv) in.readObject();
		switch (fromServer) {
			case NOK:
				System.err.println("Error: The domain already exists.");
				break;
			case OK:
				try {
					// Gerar o salt
					SecureRandom random = new SecureRandom();
					byte[] salt = new byte[16];
					random.nextBytes(salt);

					// Definir o número de iterações
					int iterations = 10000; 

					File domFile = new File("./FicheirosCliente/dom"+dom+".txt");
					domFile.createNewFile();
					try (FileOutputStream fos = new FileOutputStream(domFile); 
						 DataOutputStream dos = new DataOutputStream(fos)) {

						dos.write(salt);
						dos.writeInt(iterations);
						
					} catch (IOException e) {
						System.err.println("Failed to create the file: " + e.getMessage());
					}
					break;

				} catch (Exception e) {
					System.err.println("Error creating domain key properties: " + e.getMessage());
				}
				System.out.println("The domain was created successfully.");
				break;
			default:
				System.err.println("Error in the server.");
				break;
		}
	}

	/**
     * Handles user addition response from the server.
     * This method reads the response from the server and prints appropriate messages based on the response.
 	 *
     * @param in  ObjectInputStream for reading server response.
     * @param out ObjectOutputStream for writing to the server.
     * @throws ClassNotFoundException If a class is not found during deserialization.
     * @throws IOException If an I/O error occurs.
     */
	private static void userAdd(ObjectInputStream in, ObjectOutputStream out, String password, String userId, String domName, KeyStore keystore) throws Exception{
		//TODO tirar a keystore e os testes
		RespostaSrv fromServer = (RespostaSrv) in.readObject();
		switch (fromServer) {
			case OK:

				byte[] salt = new byte[16];
				int iterations = 0;

				// Obter o sal e as iterações, a partir de um ficheiro existente e criar uma chave de domínio
				try (FileInputStream fis = new FileInputStream("./FicheirosCliente/dom"+domName+".txt"); DataInputStream dis = new DataInputStream(fis);){
					dis.read(salt);
					iterations = dis.readInt();
				} catch (Exception e) {
					System.out.println("Error getting the domain key properties: " + e.getMessage());
				}

				// Gerar a chave de domínio usando os parâmetros fornecidos
				SecretKey domainKey = generateDomainKey(password, salt, iterations);

				// Buscar a public key e o certificado do user
				PublicKey userPublicKey = null;
				try (FileInputStream fis = new FileInputStream(truststorePath)) {

					String passTrust = "changeit";
					truststore.load(fis, passTrust.toCharArray());
					
					// Obter o certificado do usuário, da truststore
					Certificate userCertificate = truststore.getCertificate(userId);
					if (userCertificate == null) {
						throw new Exception("Certificate not found for user: " + userId);
					}
					
					// Extrair a chave pública do certificado do usuário
					userPublicKey = userCertificate.getPublicKey();
				} catch (Exception e) {
					System.out.println("Error retrieving user's public key from truststore: " + e.getMessage());
				}

				// Cifrar a chave de domínio com a chave pública do usuário
				try {
					// Iniciar cifra e cifrar a chave de dominio
					Cipher cipher = Cipher.getInstance("RSA");
					cipher.init(Cipher.WRAP_MODE, userPublicKey);
					byte[] encryptedKey = cipher.wrap(domainKey);

					// Enviar a chave de domínio cifrada para o servidor
					out.writeLong(encryptedKey.length);
					out.write(encryptedKey, 0, encryptedKey.length);
					out.flush();
				} catch (Exception e) {
					System.out.println("Error encrypting and sending domain key: " + e.getMessage());
				}
				System.out.println("User added successfully.");
				break;
			case NOPERM:
				System.out.println("Error: You don't have the required permission.");
				break;
			case NODM:
				System.out.println("Error: The domain does not exist.");
				break;
			case NOUSER:
				System.out.println("Error: The user does not exist.");
				break;
			case NOK:
				System.out.println("The user is already in the domain.");
				break;
			default:
				System.out.println("Error in the server.");
				break;
		}
	}

	/**
	 * Handles the response from the server after attempting to register the device.
	 * This method reads the response from the input stream and prints appropriate messages based on the response.
	 *
	 * @param in  ObjectInputStream for reading server response.
	 * @param out ObjectOutputStream for writing to the server.
	 * @throws ClassNotFoundException If a class is not found during deserialization.
	 * @throws IOException If an I/O error occurs.
	 */
	private static void userRegistDevice(ObjectInputStream in, ObjectOutputStream out) throws ClassNotFoundException, IOException{
		RespostaSrv fromServer = (RespostaSrv) in.readObject();
		switch (fromServer) {
			case OK:
				System.out.println("Device registered successfully.");
				break;
			case NOPERM:
				System.out.println("Error: You don't have the required permission.");
				break;
			case NODM:
				System.out.println("Error: The domain does not exist.");
				break;
			case NOK:
				System.out.println("This device is already registed in the domain.");
				break;
			default:
				System.out.println("Error in the server.");
				break;
		}
	}

	/**
	 * Handles the response from the server after attempting to send temperature value.
	 * This method reads the response from the input stream and prints appropriate messages based on the response.
	 *
	 * @param in  ObjectInputStream for reading server response.
	 * @param out ObjectOutputStream for writing to the server.
	 * @throws Exception 
	 */
	private static void userSendTempValue(String temperature, ObjectInputStream in, ObjectOutputStream out, KeyStore keystore) throws Exception{

		// Verificar se a temperatura é um float
		try {
			if(temperature.contains(",")){
				temperature = temperature.replace(",", ".");
			}
			Float.parseFloat(temperature);
		} catch (NumberFormatException e) {
			throw new Exception("Error: The temperature is not a float.");
		}
		
		// Obter as chaves dos diferentes domínios
		String[] domsKeys = (String[]) in.readObject();
		
		// Criar uma lista para colocar as temperaturas encriptadas
		List<String> encryptedTemp = new ArrayList<>();

		// Percorrer as chaves de dominio
		for (String k : domsKeys ) {
			
			Cipher c;
			SecretKey domKey;

			try {
				// Pegar a chave privada da keystore
				PrivateKey userPK = (PrivateKey) keystore.getKey(keystore.aliases().nextElement(), password_ks.toCharArray());

				// Iniciar a cifra para decifrar a chave de dominio
				c = Cipher.getInstance("RSA");
				c.init(Cipher.UNWRAP_MODE, userPK);
				domKey = (SecretKey) c.unwrap(Base64.getDecoder().decode(k), "DESede", Cipher.SECRET_KEY); // Obter a chave de domínio decifrada

				// Iniciar a cifra para cifrar o conteudo
				c = Cipher.getInstance("AES");
				SecretKeySpec spec = new SecretKeySpec(domKey.getEncoded(), "AES");
				c.init(Cipher.ENCRYPT_MODE, spec);

				byte[] input = temperature.getBytes();
				byte[] encrypted = c.doFinal(input);
				encryptedTemp.add(Base64.getEncoder().encodeToString(encrypted)); // Adicionar a temperatura encriptada à lista
			} catch (Exception e) {
				System.out.println("Erro ao decifrar a chave ao enviar a temperatura.");
				e.printStackTrace();
				return;
			}
		}

		// Enviar as temperaturas encriptadas para o servidor
		out.writeObject(encryptedTemp.toArray(new String[encryptedTemp.size()]));
		out.flush();

		// Obter a resposta do servidor
		RespostaSrv fromServer = (RespostaSrv) in.readObject();
		switch (fromServer) {
			case OK:
				System.out.println("Temperature received successfully.");
				break;
			case NOK:
				System.out.println("Error: The temperature was not accepted.");
				break;
			default:
				System.out.println("Error in the server.");
				break;
		}
	}

	/**
 	* Sends an image file to the server and handles the response.
 	* This method reads the image file specified by the filename, sends it to the server along with its length,
 	* and then waits for a response from the server. It prints appropriate messages based on the response.
 	*
 	* @param filename The path to the image file to be sent.
 	* @param in ObjectInputStream for reading server response.
 	* @param out ObjectOutputStream for writing to the server.
 	* @throws ClassNotFoundException If a class is not found during deserialization.
 	* @throws IOException If an I/O error occurs.
 	*/
	private static void userSendImage(String filename, ObjectInputStream in, ObjectOutputStream out, KeyStore keystore) throws ClassNotFoundException, IOException{

		File file = new File(filename);

		String[] domsKeys = (String[]) in.readObject();
		
		List<String> encryptedImage = new ArrayList<>();

		// Percorrer as chaves de dominio
		for (String k : domsKeys ) {
			
			Cipher c;
			SecretKey domKey;

			try {
				// Pegar a chave privada da keystore
				PrivateKey userPK = (PrivateKey) keystore.getKey(keystore.aliases().nextElement(), password_ks.toCharArray());

				// Iniciar a cifra para decifrar a chave de dominio
				c = Cipher.getInstance("RSA");
				c.init(Cipher.UNWRAP_MODE, userPK);
				domKey = (SecretKey) c.unwrap(Base64.getDecoder().decode(k), "DESede", Cipher.SECRET_KEY); // Obter a chave de domínio decifrada

				// Iniciar a cifra para cifrar o conteudo
				c = Cipher.getInstance("AES");
				SecretKeySpec spec = new SecretKeySpec(domKey.getEncoded(), "AES");
				c.init(Cipher.ENCRYPT_MODE, spec);

				byte[] fileBytes = new byte[(int) file.length()];
				try (FileInputStream fileInputStream = new FileInputStream(file)) {
					fileInputStream.read(fileBytes);
				} catch (IOException e) {
					System.out.println("Error reading the image.");
				}

				byte[] encrypted = c.doFinal(fileBytes);
				encryptedImage.add(Base64.getEncoder().encodeToString(encrypted));
			} catch (Exception e) {
				System.out.println("Erro ao decifrar a chave ao enviar a temperatura.");
				e.printStackTrace();
				return;
			}
		}
				
		out.writeObject(filename); 
		out.writeObject(encryptedImage.toArray(new String[encryptedImage.size()]));
		out.flush();
		/*
		out.writeObject(file.length()); 
		out.write(encryptedImage, 0, (int) file.length());
		out.flush();
		*/

		RespostaSrv fromServer = (RespostaSrv) in.readObject();
		switch (fromServer) {
			case OK:
				System.out.println("Image received successfully.");
				break;
			case NOK:
				System.out.println("Error: The image was not accepted.");
				break;
			default:
				System.out.println("Error in the server.");
				break;
		}
	}

	/**
 	* Receives temperature data from the server and handles the response.
 	* This method reads the response from the server and prints appropriate messages based on the response.
 	* If the response indicates successful retrieval of temperature data, it also saves the data to a file.
 	*
 	* @param in ObjectInputStream for reading server response.
 	* @param out ObjectOutputStream for writing to the server.
 	* @throws ClassNotFoundException If a class is not found during deserialization.
 	* @throws IOException If an I/O error occurs.
 	*/
	private static void userReceiveTemp(ObjectInputStream in, ObjectOutputStream out, KeyStore keystore) throws ClassNotFoundException, IOException {
		RespostaSrv fromServer = (RespostaSrv) in.readObject();
		switch (fromServer) {
			case OK:
				//a)receber chave dominio
				byte[] ciphDomKey = (byte[]) in.readObject();

				//b)decifrar chave de dominio com chave privada do user
				Cipher c;
				SecretKey domKey;
				try {
					PrivateKey userPK = (PrivateKey) keystore.getKey(keystore.aliases().nextElement(), password_ks.toCharArray());
					c = Cipher.getInstance("RSA");
					c.init(Cipher.UNWRAP_MODE, userPK);
					domKey = (SecretKey) c.unwrap(ciphDomKey, "DESede", Cipher.SECRET_KEY);
				} catch (Exception e) {
					System.out.println("Erro ao decifrar a chave ao receber as temperaturas.");
					e.printStackTrace();
					return;
				}

				//c)receber dados
				long fileSize = (long) in.readLong();
				byte[] ciphFile = new byte[(int) fileSize];
				
				in.readFully(ciphFile, 0, (int) fileSize);

				String tempsString = new String(ciphFile, StandardCharsets.UTF_8);
				StringBuilder sb = new StringBuilder();

				//d)decifrar dados com a chave de dominio decifrada em b
				String[] tempString = tempsString.split("\n");
				for (String userAndTemp : tempString) {
					if(userAndTemp.split(":", 3).length >= 3){
						sb.append(userAndTemp.split(",")[0]);
						String temp = userAndTemp.split(":", 3)[2];
						try {
							c = Cipher.getInstance("AES");
							SecretKeySpec spec = new SecretKeySpec(domKey.getEncoded(), "AES");
							c.init(Cipher.DECRYPT_MODE, spec);
							
							byte[] tempsContent = c.doFinal(Base64.getDecoder().decode(temp.trim()));
							
							sb.append(",").append(new String(tempsContent, StandardCharsets.UTF_8)).append(System.lineSeparator());
						} catch (Exception e) {
							System.out.println("Erro ao decifrar os dados de temperatura");
							e.printStackTrace();
							return;
						}
					}
				}
				
				if(sb.length() != 0){
					// e)resto das cenas
					String filePath = "./RespostasServidor/rvdTemperatures.txt"; 
					File a = new File(filePath);
					a.createNewFile();
					String content = sb.toString();

					try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
						writer.write(content);
						System.out.println("Content has been written to the file.");
					} catch (IOException e) {
						System.err.println("An error occurred while writing to the file: " + e.getMessage());
					}
				}

				System.out.println("Temperature received.");
				break;
			case NODATA:
				System.out.println("Error: The domain didn't publish any temperature.");
				break;
			case NODM:
				System.out.println("Error: The domain does not exist.");
				break;
			case NOPERM:
				System.out.println("Error: You don't have the required permission.");
				break;
			default:
				System.out.println("Error in the server.");
				break;
		}
	}

	/**
 	* Handles the reception of an image from the server.
 	* This method reads the response from the server and processes it accordingly.
 	*
 	* @param in  ObjectInputStream for reading the server response.
 	* @param out ObjectOutputStream for writing to the server.
 	* @throws ClassNotFoundException If a class is not found during deserialization.
 	* @throws IOException If an I/O error occurs.
	*/
	private static void userReceiveImage(ObjectInputStream in, ObjectOutputStream out, KeyStore keystore) throws ClassNotFoundException, IOException{
		RespostaSrv fromServer = (RespostaSrv) in.readObject();
		switch (fromServer) {
			case OK:
				//a)receber chave dominio
				byte[] ciphDom = (byte[]) in.readObject();

				//b)decifrar chave de dominio com chave privada do user
				Cipher c;
				SecretKey domKey;
				try {
					PrivateKey userPK = (PrivateKey) keystore.getKey(keystore.aliases().nextElement(), password_ks.toCharArray());
					c = Cipher.getInstance("RSA");
					c.init(Cipher.UNWRAP_MODE, userPK);
					domKey = (SecretKey) c.unwrap(ciphDom, "DESede", Cipher.SECRET_KEY);
				} catch (Exception e) {
					System.out.println("Erro ao decifrar a chave ao receber a imagem do servidor.");
					e.printStackTrace();
					return;
				}

				//c)receber dados
				long fileSize = in.readLong();
				String filename = (String) in.readObject();
				String filePath = "./RespostasServidor/"+filename;
				byte[] ciphFile = new byte[(int) fileSize];
				in.readFully(ciphFile, 0, (int) fileSize);	

				//d)decifrar dados com a chave de dominio decifrada em b
				byte[] image;
				try {
					c = Cipher.getInstance("AES");
					SecretKeySpec spec = new SecretKeySpec(domKey.getEncoded(), "AES");
					c.init(Cipher.DECRYPT_MODE, spec);

					image = c.doFinal(ciphFile);
				} catch (Exception e) {
					System.out.println("Erro ao decifrar os dados");
					e.printStackTrace();
					return;
				}


				File a = new File(filePath);
				a.createNewFile();
				
				try (FileOutputStream fos = new FileOutputStream(filePath)) {
					fos.write(image);
				} catch (IOException e) {
					System.err.println("Failed to write the image bytes: " + e.getMessage());
				}
				
				System.out.println("Image received.");
				break;
			case NODATA:
				System.out.println("Error: The device id didn't publish any data.");
				break;
			case NOID:
				System.out.println("Error: The device id does not exist.");
				break;
			case NOPERM:
				System.out.println("Error: You don't have the required permission.");
				break;
			case NOK:
				System.out.println("Error: There is something wrong with your input.");
				break;
			default:
				System.out.println("Error in the server.");
				break;
		}
	}

	
	private static void userDomains(ObjectInputStream in, ObjectOutputStream out) throws ClassNotFoundException, IOException {
		RespostaSrv fromServer = (RespostaSrv) in.readObject();
		switch (fromServer) {
			case OK:
				System.out.println("Domains:");
				String[] domainsName = (String[]) in.readObject();
				for (String domain : domainsName) {
					System.out.println(domain);
				}
				System.out.println();
				break;
			case NODATA:
				System.out.println("The Users isn't in any domain!");
				break;
			default:
				System.out.println("Error in the server.");
				break;
		}
	}

	private static void closeClient() {
		try {
			System.out.println("Closing Device!");
			sc.close();
			out.close();
			in.close();
			clientSocket.close();
		} catch (IOException e) {
			System.out.println("Erro ao fechar o cliente.");
			e.printStackTrace();
		}
	}

	private static byte[] signData(byte[] data, KeyStore keystore, String password) throws Exception {
		// Load the private key from the keystore
		PrivateKey privateKey = (PrivateKey) keystore.getKey(keystore.aliases().nextElement(), password.toCharArray());
	
		// Initialize a Signature object with the private key
		Signature signature = Signature.getInstance("SHA256withRSA");
		signature.initSign(privateKey);
	
		// Update the Signature object with the data to be signed
		signature.update(data);
	
		// Generate the signature
		return signature.sign();
	}

	private static SecretKey generateDomainKey(String password, byte[] salt, int iterations) throws Exception {
        // Geração de uma chave secreta usando PBE com SHA-256 e AES de 128 bits
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, 128);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), "AES");
    }
}