public class SensorDevice {

    private String userId;
    private int deviceId;

    public SensorDevice(String userId, int deviceId){
        this.userId = userId;
        this.deviceId = deviceId;
    }

    public String getUserId(){
        return new String(userId);
    }

    public int getDeviceId() {
        return deviceId;
    }

    // Override equals method
    @Override
    public boolean equals(Object obj) {
        // Check if the object being compared is itself
        if (this == obj) {
            return true;
        }

        // Check if the object is null or not an instance of MyClass
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        // Type cast obj to MyClass
        SensorDevice other = (SensorDevice) obj;

        // Check for equality based on the fields of MyClass
        return deviceId == other.deviceId && userId.equals(other.userId);
    }

    @Override
    public String toString(){
        return userId + ":" + deviceId;
    }
}
