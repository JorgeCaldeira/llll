Grupo de Trabalho: Grupo 49
Simão Quintas, nº58190
Manuel França, nº58215
Renato Ferreira, nº58238

Como compilar:
Os .jar foram compilados ao usar VSCode com a extensão de Java da Microsoft

Como executar:
-Para correr IoTDevice: java -jar IoTDevice.jar <serverAddress>:[port] <truststore> <keystore> <passwordkeystore> <dev-id> <user-id> (onde o port é opcional)
-Para correr IoTServer: java -jar IoTServer.jar [port] <password-cifra> <keystore> <password-keystore> <2FA-APIKey> (onde o port é opcional)
-Por default, o número do port no IoTDevice e no IoTServer é 12345
(Os argumentos estão a funcionar conforme dito no enunciado)

Limitações: 
-UserId não pode conter ":" ou "," 

Informações adicionais:
O RI retorna a imagem para a pasta "RespostasServidor" com o nome original da imagem
O RT retorna para um ficheiro com o nome "rvdTemperatures.txt" também para a pasta "RespostasServidor" com as temperaturas pedidas
Na pasta "FicheirosServidor" estão os ficheiros guardados e usados pelo IoTServer
Na pasta "FicheirosCliente" estão as keystores e truststore dos clientes

Restrições:
Ao fechar e voltar a abrir o servidor, os utilizadores que publicaram as temperaturas e as imagens não são recuperados, pelo que têm de voltar a enviar 
as informações;